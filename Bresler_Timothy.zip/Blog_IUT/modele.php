<?php require 'config/init.conf.php'; ?>

<?php include 'includes/header.inc.php'; ?>

<!-- Responsive navbar-->
<?php include 'includes/navbar.inc.php'; ?>
<!-- Page content-->
<div class="container">
    <div class="text-center mt-5">
        <h1> A Bootstrap 5 Starter Template</h1>
        <p class="lead">A complete project boilerplate built with Bootstrap</p>
        <p>Bootstrap v5.1.3</p>
    </div>
    
    <?php
    
    $articlesManager = new articlesManager ($bdd);

    $listeArticles = $articlesManager->getList() ;

//print_r2($articles);//afficher le tableau récupéré dans ArticlesManager

    ?>

<div class="row">
        <?php 
        foreach ($listeArticles as $articles){
            ?>
            <div class="col-6 mb-4">
            <div class="card">
                <img src="img/<?= $articles->getId() ?>.jpg" 
                style="max-width: 200px;" 
                class="card-img-top" alt="<?= $articles->getTitre() ?>">
                <div class="card-body">
                    <h5 class="card-title"><?= $articles->getTitre() ?></h5>
                    <p class="card-text"><?= $articles->getTexte() ?></p>
                    <a href="#" class="btn btn-primary"><?= $articles->getdate() ?></a>
                </div>
            </div>
        </div>
        <?php
        }
        ?>
</div>
</div>
<?php include 'includes/footer.inc.php'; ?>








